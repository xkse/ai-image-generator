/**
 * AI 生图站（通用版 / 大改）
 * ----------------------------------------------------------------
 * 设计目标：只要传入一个「生图模型 API」即可使用，不绑定任何特定服务商。
 * 上游调用被抽象成「可配置服务商」：
 *   - provider = openai  : OpenAI 兼容同步接口（POST 即返回图片）
 *   - provider = toapis  : 异步提交 + 轮询（ToAPIs 风格）
 *   - provider = custom  : 完全自定义（端点 / 认证 / 请求体 / 响应路径 / 轮询）
 * 所有参数均可在网页「设置」面板里填写并保存（持久化到 config.json）。
 *
 * 环境变量（部署时也可用，作为初始默认值；网页设置会覆盖并持久化）：
 *   IMAGE_API_KEY / TOAPIS_KEY         API Key（sk-mock 开头 = 模拟模式）
 *   IMAGE_API_BASE_URL / TOAPIS_BASE    API 地址
 *   IMAGE_API_MODEL                    模型名
 *   IMAGE_API_PROVIDER / TOAPIS_PROVIDER  openai | toapis | custom
 *   ACCESS_CODE                        网站访问密码（留空 = 不设密码）
 *   MOCK_MODE=1                        强制模拟模式
 *   IMAGE_API_PRICING_JSON / TOAPIS_PRICING_JSON  价格 JSON {"1k":3,"2k":4}
 *   CREDIT_RMB                         1 积分 = 多少人民币（默认 7/200）
 * 零依赖，Node.js >= 18
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT || 9000);
const HOST = process.env.HOST || '0.0.0.0';
const ENV_ACCESS_CODE = process.env.ACCESS_CODE || '';
const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;

// ---------- 配置：默认值 + 合并 + 持久化 ----------

function parseList(s) {
  if (!s) return null;
  try {
    const a = JSON.parse(s);
    if (Array.isArray(a)) return a;
  } catch (e) { /* 不是 JSON，按逗号拆分 */ }
  return s.split(',').map(x => x.trim()).filter(Boolean);
}

function parsePricing(s) {
  if (!s) return {};
  try {
    const o = JSON.parse(s);
    if (o && typeof o === 'object' && !Array.isArray(o)) return o;
  } catch (e) { /* ignore */ }
  return {};
}

// 各服务商类型的高级项默认填充值（前端切换类型时会调用同样的预设）
const PRESETS = {
  openai: {
    endpoint: '/v1/images/generations',
    authHeader: 'Authorization',
    authScheme: 'Bearer',
    requestFormat: 'openai',
    supportsResolution: false,
    sizeField: 'size',
    resolutionField: 'resolution',
    responsePath: 'data',
    responseItem: 'url',
    // 默认按 data（内联 base64）传参考图：通用性最好，多数 OpenAI 兼容中转站可直接接受
    refMode: 'data',
    refField: 'image',
    uploadEndpoint: '/v1/uploads/images',
    poll: { enabled: false, taskIdPath: 'task_id', pollEndpoint: '/v1/images/generations/{id}', statusPath: 'status', doneValue: 'completed', failValues: 'failed,error', maxWaitMs: 300000, intervalMs: 3000 }
  },
  toapis: {
    endpoint: '/v1/images/generations',
    authHeader: 'Authorization',
    authScheme: 'Bearer',
    requestFormat: 'toapis',
    supportsResolution: true,
    sizeField: 'size',
    resolutionField: 'resolution',
    responsePath: 'result.data',
    responseItem: 'url',
    refMode: 'upload',
    refField: 'reference_images',
    uploadEndpoint: '/v1/uploads/images',
    poll: { enabled: true, taskIdPath: 'id', pollEndpoint: '/v1/images/generations/{id}', statusPath: 'status', doneValue: 'completed', failValues: 'failed,error', maxWaitMs: 300000, intervalMs: 3000 }
  },
  custom: {
    endpoint: '/v1/images/generations',
    authHeader: 'Authorization',
    authScheme: 'Bearer',
    requestFormat: 'custom',
    supportsResolution: true,
    sizeField: 'size',
    resolutionField: 'resolution',
    responsePath: 'data',
    responseItem: 'url',
    refMode: 'data',
    refField: 'reference_images',
    uploadEndpoint: '/v1/uploads/images',
    poll: { enabled: false, taskIdPath: 'task_id', pollEndpoint: '/v1/images/generations/{id}', statusPath: 'status', doneValue: 'completed', failValues: 'failed,error', maxWaitMs: 300000, intervalMs: 3000 }
  }
};

function defaultConfig() {
  const toapisKey = process.env.TOAPIS_KEY || '';
  const imageKey = process.env.IMAGE_API_KEY || toapisKey;
  const base = process.env.IMAGE_API_BASE_URL || process.env.TOAPIS_BASE || '';
  const legacyToapis = !!toapisKey && !process.env.IMAGE_API_KEY;
  const provider = process.env.IMAGE_API_PROVIDER || process.env.TOAPIS_PROVIDER || (legacyToapis ? 'toapis' : 'openai');
  const preset = PRESETS[provider] || PRESETS.custom;
  return {
    provider,
    name: process.env.IMAGE_API_NAME || (provider === 'toapis' ? 'ToAPIs' : '我的生图 API'),
    baseUrl: base,
    apiKey: imageKey,
    model: process.env.IMAGE_API_MODEL || (provider === 'toapis' ? 'gpt-image-2' : ''),
    endpoint: process.env.IMAGE_API_ENDPOINT || preset.endpoint,
    authHeader: process.env.IMAGE_API_AUTH_HEADER || preset.authHeader,
    authScheme: process.env.IMAGE_API_AUTH_SCHEME || preset.authScheme,
    requestFormat: process.env.IMAGE_API_REQUEST_FORMAT || preset.requestFormat,
    supportsResolution: process.env.IMAGE_API_SUPPORTS_RESOLUTION === '1' || preset.supportsResolution,
    sizeField: process.env.IMAGE_API_SIZE_FIELD || preset.sizeField,
    resolutionField: process.env.IMAGE_API_RESOLUTION_FIELD || preset.resolutionField,
    responsePath: process.env.IMAGE_API_RESPONSE_PATH || preset.responsePath,
    responseItem: process.env.IMAGE_API_RESPONSE_ITEM || preset.responseItem,
    // auto = 按服务商预设自动决定参考图传输方式（toapis→upload，其余→data）
    refMode: process.env.IMAGE_API_REF_MODE || 'auto',
    refField: process.env.IMAGE_API_REF_FIELD || preset.refField,
    uploadEndpoint: process.env.IMAGE_API_UPLOAD_ENDPOINT || preset.uploadEndpoint,
    poll: { ...preset.poll, ...(process.env.IMAGE_API_POLL === '1' ? { enabled: true } : {}) },
    pricing: parsePricing(process.env.IMAGE_API_PRICING_JSON || process.env.TOAPIS_PRICING_JSON),
    creditRmb: Number(process.env.CREDIT_RMB) || (7 / 200),
    maxRefImages: Number(process.env.IMAGE_API_MAX_REF) || 10,
    maxN: Number(process.env.IMAGE_API_MAX_N) || 4,
    sizes: parseList(process.env.IMAGE_API_SIZES) || ['1:1', '4:5', '5:4', '3:4', '4:3', '2:3', '3:2', '9:16', '16:9', '1:2', '2:1', '9:21', '21:9'],
    resolutions: parseList(process.env.IMAGE_API_RESOLUTIONS) || ['1k', '2k', '4k'],
    mockMode: process.env.MOCK_MODE === '1' || /^sk-mock/i.test(imageKey),
    accessCode: ENV_ACCESS_CODE
  };
}

// 把保存的配置安全地合并到默认配置上，避免缺字段导致崩溃
function mergeConfig(def, saved) {
  if (!saved || typeof saved !== 'object') return def;
  const out = { ...def, ...saved };
  out.poll = { ...def.poll, ...(saved.poll && typeof saved.poll === 'object' ? saved.poll : {}) };
  out.mockMode = !!saved.mockMode;
  out.supportsResolution = !!saved.supportsResolution;
  out.poll.enabled = !!out.poll.enabled;
  out.creditRmb = Number(saved.creditRmb) || def.creditRmb;
  out.maxRefImages = Number(saved.maxRefImages) || def.maxRefImages;
  out.maxN = Number(saved.maxN) || def.maxN;
  if (saved.sizes) out.sizes = saved.sizes;
  if (saved.resolutions) out.resolutions = saved.resolutions;
  if (saved.pricing && typeof saved.pricing === 'object') out.pricing = saved.pricing;
  if (typeof saved.accessCode === 'string') out.accessCode = saved.accessCode;
  // 旧配置迁移：老版本的 refMode 默认值就是 'none'（当时语义=「不支持」），
  // 新版把它拆成 auto（自动）与 off（显式关闭）。历史 'none' 属于默认值而非用户主动关闭，
  // 迁移为 'auto'，否则图生图入口会被一直藏起来（用户看不到参考图就是这个原因）。
  if (String(saved.refMode || '').toLowerCase() === 'none') out.refMode = 'auto';
  return out;
}

function configCandidates() {
  return [path.join(__dirname, 'config.json'), '/tmp/config.json'];
}

function loadConfig() {
  const def = defaultConfig();
  for (const p of configCandidates()) {
    try {
      if (fs.existsSync(p)) {
        const saved = JSON.parse(fs.readFileSync(p, 'utf8'));
        console.log('已加载配置：' + p);
        return mergeConfig(def, saved);
      }
    } catch (e) { console.warn('读取配置失败 ' + p + '：' + e.message); }
  }
  return def;
}

function saveConfig(cfg) {
  const json = JSON.stringify(cfg, null, 2);
  let lastErr = null;
  for (const p of configCandidates()) {
    try { fs.writeFileSync(p, json); return p; }
    catch (e) { lastErr = e; }
  }
  try { fs.writeFileSync('/tmp/config.json', json); return '/tmp/config.json'; }
  catch (e) { throw new Error('无法保存配置（文件系统可能只读）：' + (lastErr && lastErr.message)); }
}

let config = loadConfig();

function isMock(cfg) {
  return cfg.mockMode || /^sk-mock/i.test(cfg.apiKey || '');
}

// ---------- 工具函数 ----------

function sendJSON(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

function authorized(req) {
  const code = config.accessCode || ENV_ACCESS_CODE;
  if (!code) return true;
  return req.headers['x-access-code'] === code;
}

function getByPath(obj, p) {
  if (!p || p === '') return obj;
  return String(p).split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
}

// 拼接 Base URL 与路径，自动去重重复的 /v1 段：
// 无论用户把 Base URL 填成 host 根（https://x.com）还是带 /v1 前缀（https://x.com/v1），
// 都能拼出正确地址，避免 /v1/v1/images/... 这种错误。
function joinUrl(base, path) {
  base = String(base || '').replace(/\/+$/, '');
  path = '/' + String(path || '').replace(/^\/+/, '');
  const seg = base.match(/\/v\d+$/i);
  if (seg && path.startsWith(seg[0] + '/')) {
    path = path.slice(seg[0].length);
    if (!path.startsWith('/')) path = '/' + path;
  }
  return base + path;
}

function normalizeResolution(value) {
  return String(value || '1k').toLowerCase().replace(/\s/g, '');
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// 带重试的通用请求（接收完整 URL）
async function fetchWithRetry(fullUrl, options, timeoutMs, retries, retryOn5xx) {
  const maxRetries = retries === undefined ? 2 : retries;
  let lastError = null;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs || 35000);
    try {
      const resp = await fetch(fullUrl, { ...options, signal: controller.signal });
      clearTimeout(timer);
      const text = await resp.text();
      let json = null;
      try { json = JSON.parse(text); } catch (e) { /* 非 JSON */ }
      const serverErr = resp.status >= 500;
      if (serverErr && retryOn5xx && attempt < maxRetries) {
        await sleep(700 * (attempt + 1));
        continue;
      }
      return { status: resp.status, json, text };
    } catch (e) {
      clearTimeout(timer);
      lastError = e;
      if (e.name === 'AbortError' || attempt >= maxRetries) throw e;
      await sleep(700 * (attempt + 1));
    }
  }
  throw lastError;
}

function upstreamError(result) {
  const j = result.json;
  if (j) {
    if (j.error && j.error.message) return j.error.message;
    if (typeof j.error === 'string') return j.error;
    if (j.message) return j.message;
  }
  return (result.text || '').slice(0, 300) || ('上游返回 HTTP ' + result.status);
}

function friendlyError(result) {
  const raw = upstreamError(result) || '';
  if (result.status === 401) return 'API Key 无效或未配置，请在「设置」里检查';
  if (result.status === 403) return '没有权限调用该模型（可能未开通或受限）';
  if (result.status === 429) return '请求太频繁，请等几秒再试';
  if (result.status >= 500) return '上游服务暂时不可用（HTTP ' + result.status + '），请稍后重试';
  return raw;
}

// 判定为图片模型的关键词（用于 /models 列表筛选）
const IMAGE_KEYWORDS = [
  'image', 'img', 'dall-e', 'dalle', 'gpt-4o-image', 'flux', 'midjourney', 'mj-', 'mj_',
  'niji', 'seedream', 'seededit', 'doubao', 'cogview', 'stable-diffusion', 'sdxl',
  'sd3', 'ideogram', 'recraft', 'banana', 'gemini', 'imagen', 'wanx', 'jimeng',
  'hunyuan-image', 'kolors', 'hidream', 'pixart', 'qwen-image', 'grok-imagine', 'vidu'
];

function filterImageModels(list) {
  const seen = new Set();
  const out = [];
  for (const m of list) {
    const raw = typeof m === 'string' ? m : (m && (m.id || m.name));
    if (!raw) continue;
    const id = String(raw).toLowerCase();
    const type = String(m && (m.type || m.category || m.modality || '')).toLowerCase();
    const caps = JSON.stringify(m && (m.capabilities || m.input_modalities || m.output_modalities || '')).toLowerCase();
    const clearlyImage = /image|图片|图像/.test(type + caps);
    const looksLikeImage = IMAGE_KEYWORDS.some(k => id.includes(k)) && !/(video|audio|embedding|tts|transcri)/.test(id);
    if ((clearlyImage || looksLikeImage) && !seen.has(id)) {
      seen.add(id);
      out.push(raw);
    }
  }
  return out.sort();
}

// ---------- 模型能力表（决定「当前选中的模型」开放哪些模式） ----------
// modes: text2img = 文生图（只需提示词）；img2img = 图生图（可带参考图）
// 能力表里没命中的图片模型给「宽松默认」：文生图 + 图生图，
// 避免不知道能力时把参考图入口整个藏掉（用户完全看不到图生图入口就是这个原因）。
const DEFAULT_MODEL_CAPS = {
  modes: ['text2img', 'img2img'],
  maxRefImages: 10,
  maxN: 4,
  resolutions: ['1k', '2k', '4k'],
  sizes: null
};

const MODEL_CAPS = [
  { match: /gpt-image|dall-?e/i, modes: ['text2img', 'img2img'], maxRefImages: 10, maxN: 4, resolutions: ['1k', '2k', '4k'] },
  { match: /nano-?banana|gemini.*image|imagen/i, modes: ['text2img', 'img2img'], maxRefImages: 6, maxN: 4, resolutions: ['1k', '2k', '4k'] },
  { match: /seedream|doubao|jimeng|即梦/i, modes: ['text2img', 'img2img'], maxRefImages: 10, maxN: 4, resolutions: ['1k', '2k', '4k'] },
  { match: /flux/i, modes: ['text2img', 'img2img'], maxRefImages: 8, maxN: 4, resolutions: ['1k', '2k'] },
  { match: /qwen-?image|wanx|wan2|万相/i, modes: ['text2img', 'img2img'], maxRefImages: 3, maxN: 1, resolutions: ['1k', '2k'] },
  { match: /grok/i, modes: ['text2img', 'img2img'], maxRefImages: 5, maxN: 4, resolutions: [] },
  { match: /midjourney|(^|[^a-z])mj([^a-z]|$)/i, modes: ['text2img', 'img2img'], maxRefImages: 4, maxN: 4, resolutions: [] },
  { match: /kolors|ideogram|recraft|stable-?diffusion|sd-?xl|sd-?3/i, modes: ['text2img', 'img2img'], maxRefImages: 4, maxN: 4, resolutions: ['1k', '2k'] }
];

// 计算某个模型能力：能力表命中值优先；用户在「设置」里填的上限作为安全上限（取更小值）
function modelCapsFor(modelId, cfg) {
  const id = String(modelId || '').toLowerCase();
  const hit = MODEL_CAPS.find(c => c.match.test(id));
  const caps = { ...DEFAULT_MODEL_CAPS, ...(hit || {}) };
  caps.modes = Array.isArray(caps.modes) && caps.modes.length ? caps.modes.slice() : ['text2img'];
  caps.resolutions = Array.isArray(caps.resolutions) ? caps.resolutions.map(r => String(r).toLowerCase()) : [];
  caps.sizes = Array.isArray(caps.sizes) && caps.sizes.length ? caps.sizes.slice() : null;

  const userMaxRef = Number(cfg && cfg.maxRefImages) || 0;
  if (userMaxRef > 0 && userMaxRef < caps.maxRefImages) caps.maxRefImages = userMaxRef;
  const userMaxN = Number(cfg && cfg.maxN) || 0;
  if (userMaxN > 0 && userMaxN < caps.maxN) caps.maxN = userMaxN;

  // 分辨率：能力表说「不要这个字段」（空数组）时就不传；否则与设置里的档位取交集
  const apiSupportsRes = !!(cfg && cfg.supportsResolution);
  const userRes = (cfg && Array.isArray(cfg.resolutions) && cfg.resolutions.length)
    ? cfg.resolutions.map(r => String(r).toLowerCase()) : null;
  if (caps.resolutions.length && userRes) {
    const inter = caps.resolutions.filter(r => userRes.includes(r));
    if (inter.length) caps.resolutions = inter;
  }
  caps.supportsResolution = apiSupportsRes && caps.resolutions.length > 0;

  // 比例：设置里填了就取交集，没填则不限
  const userSizes = (cfg && Array.isArray(cfg.sizes) && cfg.sizes.length) ? cfg.sizes : null;
  if (userSizes) caps.sizes = caps.sizes ? caps.sizes.filter(s => userSizes.includes(s)) : userSizes.slice();
  if (caps.sizes && caps.sizes.length === 0) caps.sizes = null;

  return caps;
}

// 参考图的「传输方式」：auto = 按服务商预设自动（toapis→upload，其余→data）
function effectiveRefMode(cfg) {
  const m = String((cfg && cfg.refMode) || 'auto').toLowerCase();
  if (!m || m === 'auto') {
    const preset = PRESETS[(cfg && cfg.provider) || 'custom'] || PRESETS.custom;
    return preset.refMode;
  }
  return m;
}

// ---------- 服务商通用调用 ----------

function authHeaders(cfg) {
  const h = {};
  const header = cfg.authHeader || 'Authorization';
  const key = cfg.apiKey || '';
  const scheme = cfg.authScheme;
  h[header] = (scheme && scheme !== 'none' && scheme !== '') ? (scheme + ' ' + key) : key;
  return h;
}

function buildBody(cfg, params) {
  const body = {};
  body.model = params.model || cfg.model;
  body.prompt = params.prompt;
  const n = Math.max(1, parseInt(params.n, 10) || 1);
  if (n > 1) body.n = n;
  const size = params.size;
  if (size && size !== 'auto') body[cfg.sizeField || 'size'] = size;
  if (cfg.supportsResolution && params.resolution && params.resolution !== 'auto') {
    body[cfg.resolutionField || 'resolution'] = params.resolution;
  }
  if (params.refUrls && params.refUrls.length) {
    body[cfg.refField || 'reference_images'] = params.refUrls;
  }
  return body;
}

function urlOrData(s) {
  if (/^https?:\/\//.test(s)) return { url: s };
  return { dataUrl: maybeB64(s) };
}
function maybeB64(s) {
  return /^data:/.test(s) ? s : ('data:image/png;base64,' + s);
}

// 从响应里稳健提取图片数组；先按配置的 responsePath，失败再试常见候选路径
function extractImages(result, cfg) {
  const out = [];
  const push = (item) => {
    if (!item) return;
    if (typeof item === 'string') { out.push(urlOrData(item)); return; }
    const ri = cfg.responseItem || 'url';
    if (ri === 'b64_json' && item.b64_json) { out.push({ dataUrl: 'data:image/png;base64,' + item.b64_json }); return; }
    if (ri === 'output' && item.output) { out.push(urlOrData(item.output)); return; }
    if (item.url) { out.push({ url: item.url }); return; }
    if (item.b64_json) { out.push({ dataUrl: 'data:image/png;base64,' + item.b64_json }); return; }
    if (item.output) { out.push(urlOrData(item.output)); return; }
  };
  const primary = getByPath(result, cfg.responsePath || 'data');
  if (Array.isArray(primary)) { primary.forEach(push); if (out.length) return out; }
  const candidates = [
    result && result.result && result.result.data,
    result && result.data && result.data.images,
    result && result.data && result.data.data,
    result && result.images,
    result && result.output,
    result && result.result && result.result.images
  ];
  for (const c of candidates) {
    if (Array.isArray(c)) { c.forEach(push); if (out.length) return out; }
  }
  if (primary && !Array.isArray(primary)) push(primary);
  return out;
}

// 异步轮询（ToAPIs 风格）
async function pollTask(cfg, taskId) {
  const p = cfg.poll;
  const endpoint = (p.pollEndpoint || '/v1/images/generations/{id}').replace(/\{id\}/g, taskId);
  const url = joinUrl(cfg.baseUrl, endpoint);
  const headers = authHeaders(cfg);
  const start = Date.now();
  const doneVals = String(p.doneValue || 'completed').split(',').map(s => s.trim().toLowerCase());
  const failVals = String(p.failValues || 'failed,error').split(',').map(s => s.trim().toLowerCase());
  let failStreak = 0;
  const maxWait = Number(p.maxWaitMs) || 300000;
  const interval = Number(p.intervalMs) || 3000;
  while (Date.now() - start < maxWait) {
    try {
      const r = await fetchWithRetry(url, { method: 'GET', headers }, 30000, 1, true);
      if (r.status === 200 && r.json) {
        failStreak = 0;
        const status = String(getByPath(r.json, p.statusPath || 'status') || '').toLowerCase();
        if (doneVals.includes(status)) return r.json;
        if (failVals.includes(status)) {
          const msg = getByPath(r.json, 'error.message') || getByPath(r.json, 'message') || '任务执行失败';
          throw new Error('生图失败：' + msg);
        }
      } else {
        failStreak++;
        if (failStreak >= 5) throw new Error('查询任务失败：' + friendlyError(r));
      }
    } catch (e) {
      if (String(e.message).indexOf('生图失败') === 0) throw e;
      failStreak++;
      if (failStreak >= 5) throw new Error('查询任务失败（网络不稳定）：' + e.message);
    }
    await sleep(interval);
  }
  throw new Error('生图超时，任务仍在处理中，请稍后到服务商控制台查看结果');
}

// 通用生成主流程
async function callProviderGenerate(cfg, params) {
  const body = buildBody(cfg, params);
  const headers = { ...authHeaders(cfg), 'Content-Type': 'application/json' };
  const url = joinUrl(cfg.baseUrl, cfg.endpoint || '/v1/images/generations');

  const submit = await fetchWithRetry(url, { method: 'POST', headers, body: JSON.stringify(body) }, 60000, 1, false);
  if (submit.status !== 200) {
    throw new Error('提交任务失败：' + friendlyError(submit));
  }
  if (!submit.json) {
    throw new Error('上游返回了空响应（HTTP ' + submit.status + '）');
  }

  let finalResult = submit.json;
  if (cfg.poll && cfg.poll.enabled) {
    const taskId = getByPath(submit.json, cfg.poll.taskIdPath || 'task_id');
    if (!taskId) throw new Error('提交成功但未返回任务 ID，无法轮询（请检查「任务 ID 路径」设置）');
    finalResult = await pollTask(cfg, taskId);
  }

  const images = extractImages(finalResult, cfg);
  if (images.length === 0) {
    throw new Error('生成完成但未返回图片，请检查响应格式或在「设置 → 高级」里调整「响应数组路径 / 响应条目字段」');
  }
  return { images, revised_prompt: getByPath(finalResult, 'revised_prompt') || '' };
}

// ---------- 模拟模式（假 Key 体验全流程，不扣积分） ----------

function mockCanvasSize(size, resolution) {
  let w = 1024, h = 1024;
  if (size && /^\d+:\d+$/.test(size)) {
    const parts = size.split(':').map(Number);
    if (parts[0] > 0 && parts[1] > 0) {
      if (parts[0] >= parts[1]) { w = 1024; h = Math.round(1024 * parts[1] / parts[0]); }
      else { h = 1024; w = Math.round(1024 * parts[0] / parts[1]); }
    }
  }
  const mult = (resolution === '2k') ? 1.5 : (resolution === '4k') ? 2 : 1;
  return { w: Math.round(w * mult), h: Math.round(h * mult) };
}

function xmlEsc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function mockImage(model, prompt, size, resolution, refCount, index, total) {
  const { w, h } = mockCanvasSize(size, resolution);
  const fs = Math.max(15, Math.round(w / 34));
  const fsSmall = Math.max(12, Math.round(w / 55));
  const shortPrompt = prompt.length > 60 ? prompt.slice(0, 60) + '…' : prompt;
  const svg =
    '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '">' +
    '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
    '<stop offset="0" stop-color="#1a1633"/><stop offset="1" stop-color="#12182b"/></linearGradient></defs>' +
    '<rect width="100%" height="100%" fill="url(#g)"/>' +
    '<rect x="8" y="8" width="' + (w - 16) + '" height="' + (h - 16) + '" fill="none" stroke="#7c5cff" stroke-width="3" stroke-dasharray="14 8" rx="18"/>' +
    '<text x="50%" y="38%" text-anchor="middle" font-size="' + Math.round(fs * 1.9) + '">🧪</text>' +
    '<text x="50%" y="50%" text-anchor="middle" fill="#e8eaf0" font-size="' + fs + '" font-weight="bold" font-family="sans-serif">模拟生图（假 Key 演示）</text>' +
    '<text x="50%" y="58%" text-anchor="middle" fill="#9aa0b4" font-size="' + fsSmall + '" font-family="sans-serif">' + xmlEsc(model) + ' · 比例 ' + xmlEsc(size || '自动') + ' · 分辨率 ' + xmlEsc((resolution || '自动').toUpperCase()) + '</text>' +
    (refCount > 0 ? '<text x="50%" y="66%" text-anchor="middle" fill="#ffd700" font-size="' + fsSmall + '" font-family="sans-serif">图生图模式 · 参考图 ' + refCount + ' 张</text>' : '') +
    '<text x="50%" y="' + (refCount > 0 ? 74 : 66) + '%" text-anchor="middle" fill="#6c7293" font-size="' + fsSmall + '" font-family="sans-serif">' + xmlEsc(shortPrompt) + '</text>' +
    (total > 1 ? '<text x="50%" y="94%" text-anchor="middle" fill="#6c7293" font-size="' + fsSmall + '" font-family="sans-serif">' + (index + 1) + ' / ' + total + '</text>' : '') +
    '</svg>';
  return { dataUrl: 'data:image/svg+xml;base64,' + Buffer.from(svg).toString('base64') };
}

async function handleMockGenerate(input) {
  const n = Math.max(1, Math.min(parseInt(input.n, 10) || 1, 4));
  const refCount = Array.isArray(input.reference_images) ? input.reference_images.length : 0;
  await sleep(2200);
  const images = [];
  for (let i = 0; i < n; i++) {
    images.push(mockImage(input.model, input.prompt, input.size, input.resolution, refCount, i, n));
  }
  return {
    images,
    revised_prompt: '【模拟模式】这是假 Key 演示流程，未真实生图、未扣积分。在「设置」里填入真实 API 后即可正常生图。',
    mock: true
  };
}

// ---------- 路由：模型列表 ----------

function buildModelsResponse(cfg, models, source, note) {
  const pricing = {};
  const priceDetails = {};
  const constraints = {};
  const tiers = (cfg.pricing && typeof cfg.pricing === 'object') ? cfg.pricing : null;
  models.forEach(id => {
    const caps = modelCapsFor(id, cfg);
    constraints[id] = {
      modes: caps.modes,
      supportsImageInput: caps.modes.includes('img2img'),
      maxRefImages: caps.maxRefImages,
      maxN: caps.maxN,
      resolutions: caps.resolutions,
      sizes: caps.sizes,
      supportsResolution: caps.supportsResolution
    };
    const key = normalizeResolution((caps.resolutions && caps.resolutions[0]) || '1k');
    pricing[id] = tiers && tiers[key] != null ? Number(tiers[key]) : null;
    priceDetails[id] = {
      tiers: tiers,
      defaultResolution: (caps.resolutions && caps.resolutions[0]) || '1k',
      unit: 'credits/image',
      source: tiers ? 'config' : 'none'
    };
  });
  return {
    models, pricing, priceDetails, constraints,
    creditRmb: Number(cfg.creditRmb) || (7 / 200),
    provider: cfg.provider,
    name: cfg.name,
    defaultModel: cfg.model || '',
    // 参考图传输方式（auto 已解析为实际值）：前端据此决定走「内联 base64」还是「先上传换 URL」
    refMode: effectiveRefMode(cfg),
    // 只要清单里有任一模型支持图生图，就说明本站具备图生图能力
    supportsImageInput: models.some(id => constraints[id].supportsImageInput),
    source, note: note || '',
    mock: isMock(cfg)
  };
}

async function handleModels(req, res) {
  if (!authorized(req)) return sendJSON(res, 401, { error: '访问密码不正确' });
  const cfg = config;

  if (isMock(cfg)) {
    const models = cfg.model ? [cfg.model] : ['demo-model'];
    return sendJSON(res, 200, buildModelsResponse(cfg, models, 'mock', '模拟模式：价格仅用于界面演示'));
  }

  try {
    const url = joinUrl(cfg.baseUrl, '/models');
    const r = await fetchWithRetry(url, { method: 'GET', headers: authHeaders(cfg) }, 30000, 2, true);
    if (r.status === 200 && r.json) {
      const list = Array.isArray(r.json.data) ? r.json.data : (Array.isArray(r.json) ? r.json : []);
      // filterImageModels 需要模型对象（读取 type / capabilities），直接传 list；
      // 若上游只返回字符串数组也能处理（typeof m === 'string'）。
      const imageModels = filterImageModels(list);
      if (imageModels.length) return sendJSON(res, 200, buildModelsResponse(cfg, imageModels, 'live'));
      if (cfg.model) return sendJSON(res, 200, buildModelsResponse(cfg, [cfg.model], 'live-single', '已获取模型列表，但未识别出图片模型，使用设置中的模型'));
    }
    if (cfg.model) return sendJSON(res, 200, buildModelsResponse(cfg, [cfg.model], 'config', '未能从 /models 识别出图片模型，使用设置中配置的模型'));
    return sendJSON(res, 200, buildModelsResponse(cfg, [], 'none', '该 API 未返回模型列表，请在「设置」里填写模型名'));
  } catch (e) {
    if (cfg.model) return sendJSON(res, 200, buildModelsResponse(cfg, [cfg.model], 'config', '模型列表获取失败：' + e.message));
    return sendJSON(res, 200, buildModelsResponse(cfg, [], 'none', '模型列表获取失败：' + e.message));
  }
}

// ---------- 路由：参考图上传（refMode = upload 时） ----------

async function handleUpload(req, res, bodyBuf, query) {
  if (!authorized(req)) return sendJSON(res, 401, { error: '访问密码不正确' });
  const cfg = config;
  const refModeEff = effectiveRefMode(cfg);
  if (refModeEff !== 'upload') {
    return sendJSON(res, 400, { error: '当前参考图传输方式是「' + (refModeEff === 'data' ? '内联 base64' : '不使用参考图') + '」，无需上传。如需上传取 URL，请在「设置 → 参考图」把方式改为 upload' });
  }
  if (!bodyBuf || bodyBuf.length === 0) return sendJSON(res, 400, { error: '没有收到图片数据' });
  if (bodyBuf.length > MAX_UPLOAD_BYTES) return sendJSON(res, 400, { error: '图片超过 10MB 上限，请压缩后再试' });

  const filename = (query.get('filename') || 'reference.png').replace(/[^a-zA-Z0-9._-]/g, '_');
  const mime = query.get('mime') || 'image/png';
  if (!/^image\/(jpeg|png|webp|gif)$/.test(mime)) return sendJSON(res, 400, { error: '仅支持 JPG / PNG / WebP / GIF 图片' });

  if (isMock(cfg)) {
    return sendJSON(res, 200, {
      url: 'https://mock.local/uploads/' + Date.now() + '_' + Math.random().toString(36).slice(2, 10) + '.png',
      mock: true
    });
  }

  const boundary = '----FormBoundary' + Date.now().toString(36) + Math.random().toString(36).slice(2);
  const head = Buffer.from(
    '--' + boundary + '\r\n' +
    'Content-Disposition: form-data; name="file"; filename="' + filename + '"\r\n' +
    'Content-Type: ' + mime + '\r\n\r\n'
  );
  const tail = Buffer.from('\r\n--' + boundary + '--\r\n');
  const multipartBody = Buffer.concat([head, bodyBuf, tail]);

  try {
    const url = joinUrl(cfg.baseUrl, cfg.uploadEndpoint || '/v1/uploads/images');
    const result = await fetchWithRetry(url, {
      method: 'POST',
      headers: { ...authHeaders(cfg), 'Content-Type': 'multipart/form-data; boundary=' + boundary },
      body: multipartBody
    }, 60000, 2, true);

    if (result.status !== 200 || !result.json) {
      return sendJSON(res, 502, { error: '上传失败：' + friendlyError(result) });
    }
    // 兼容多种返回结构：{url} / {data:{url}} / {data:{image_url}} / {image_url}
    const url_out = result.json.url || (result.json.data && (result.json.data.url || result.json.data.image_url)) || result.json.image_url;
    if (!url_out) return sendJSON(res, 502, { error: '上传失败：接口未返回图片地址' });
    return sendJSON(res, 200, { url: url_out });
  } catch (e) {
    const msg = e.name === 'AbortError' ? '上传超时，请重试' : ('上传异常：' + e.message);
    return sendJSON(res, 504, { error: msg });
  }
}

// ---------- 路由：生成 ----------

async function handleGenerate(req, res, body) {
  if (!authorized(req)) return sendJSON(res, 401, { error: '访问密码不正确' });
  let input;
  try { input = JSON.parse(body || '{}'); } catch (e) { return sendJSON(res, 400, { error: '请求格式错误' }); }
  const model = (input.model || config.model || '').trim();
  const prompt = (input.prompt || '').trim();
  if (!model) return sendJSON(res, 400, { error: '请先在「设置」里填写模型名，或等待模型列表加载' });
  if (!prompt) return sendJSON(res, 400, { error: '请输入图片描述' });

  const requestedN = Math.max(1, Math.min(parseInt(input.n, 10) || 1, Number(config.maxN) || 4));
  const requestedResolution = normalizeResolution(input.resolution || 'auto');
  const requestedSize = String(input.size || 'auto');

  // 按「当前选中的模型」取能力（而不是全局一刀切）
  const caps = modelCapsFor(model, config);

  // 参数校验（基于该模型的能力）
  if (caps.supportsResolution && requestedResolution !== 'auto' &&
    Array.isArray(caps.resolutions) && caps.resolutions.length > 0 &&
    !caps.resolutions.includes(requestedResolution)) {
    return sendJSON(res, 400, { error: '模型「' + model + '」不支持 ' + requestedResolution.toUpperCase() + ' 分辨率，可选：' + caps.resolutions.join('、') });
  }
  if (Array.isArray(caps.sizes) && requestedSize !== 'auto' && !caps.sizes.includes(requestedSize)) {
    return sendJSON(res, 400, { error: '模型「' + model + '」不支持 ' + requestedSize + ' 比例，可选：' + caps.sizes.join('、') });
  }

  let refUrls = [];
  if (Array.isArray(input.reference_images) && input.reference_images.length > 0) {
    if (!caps.modes.includes('img2img')) {
      return sendJSON(res, 400, { error: '模型「' + model + '」只支持文生图，不支持参考图（图生图）。请换一个支持图生图的模型，或清空参考图' });
    }
    refUrls = input.reference_images
      .map(u => (typeof u === 'string' ? u.trim() : ''))
      .filter(u => u && (u.startsWith('http') || u.startsWith('data:')))
      .slice(0, caps.maxRefImages);
    if (refUrls.length === 0) return sendJSON(res, 400, { error: '参考图地址无效（需为 http(s) 或 data: URL）' });
  }
  const finalN = Math.min(requestedN, caps.maxN || 4);

  if (isMock(config)) {
    try {
      return sendJSON(res, 200, await handleMockGenerate({
        model, prompt, size: requestedSize, resolution: requestedResolution,
        n: finalN, reference_images: refUrls
      }));
    } catch (e) { return sendJSON(res, 500, { error: '模拟生成异常：' + e.message }); }
  }

  try {
    const out = await callProviderGenerate(config, {
      model, prompt, size: requestedSize, resolution: requestedResolution, n: finalN, refUrls
    });
    return sendJSON(res, 200, out);
  } catch (e) {
    let msg = e.name === 'AbortError' ? '请求超时，请稍后重试' : ('请求异常：' + e.message);
    return sendJSON(res, 504, { error: msg });
  }
}

// ---------- 路由：设置 ----------

function sanitizeConfig(input) {
  const src = (input && typeof input === 'object') ? input : {};
  const provider = ['openai', 'toapis', 'custom'].includes(src.provider) ? src.provider : 'openai';
  // 预设跟随「用户选择的服务商」，而不是环境变量推断的默认值，
  // 否则选了 toapis 却会因继承 openai 预设而把 poll.enabled 变成 false。
  const preset = PRESETS[provider] || PRESETS.custom;
  const def = defaultConfig();
  const out = { ...def, ...src };
  out.provider = provider;
  if (!out.endpoint || !String(out.endpoint).startsWith('/')) out.endpoint = preset.endpoint;
  out.authHeader = out.authHeader || preset.authHeader;
  out.authScheme = out.authScheme || preset.authScheme;
  out.requestFormat = out.requestFormat || preset.requestFormat;
  out.supportsResolution = src.supportsResolution !== undefined ? !!src.supportsResolution : preset.supportsResolution;
  out.sizeField = out.sizeField || preset.sizeField;
  out.resolutionField = out.resolutionField || preset.resolutionField;
  out.responsePath = out.responsePath || preset.responsePath;
  out.responseItem = out.responseItem || preset.responseItem;
  // auto 是有效值，不要回退成预设的固定值
  const refModeRaw = String(out.refMode || 'auto').toLowerCase();
  out.refMode = ['auto', 'off', 'none', 'data', 'upload'].includes(refModeRaw) ? refModeRaw : 'auto';
  out.refField = out.refField || preset.refField;
  out.uploadEndpoint = out.uploadEndpoint || preset.uploadEndpoint;
  out.poll = { ...preset.poll, ...(src.poll && typeof src.poll === 'object' ? src.poll : {}) };
  out.poll.enabled = !!out.poll.enabled;
  out.mockMode = !!out.mockMode;
  out.creditRmb = Number(out.creditRmb) || def.creditRmb;
  out.maxRefImages = Number(out.maxRefImages) || def.maxRefImages;
  out.maxN = Number(out.maxN) || def.maxN;
  if (typeof out.accessCode !== 'string') out.accessCode = def.accessCode;
  if (out.pricing && typeof out.pricing === 'object') {
    // 仅保留数字价阶
    const clean = {};
    Object.entries(out.pricing).forEach(([k, v]) => { if (Number.isFinite(Number(v))) clean[k] = Number(v); });
    out.pricing = clean;
  } else { out.pricing = {}; }
  return out;
}

async function handleGetSettings(req, res) {
  if (!authorized(req)) return sendJSON(res, 401, { error: '访问密码不正确' });
  // 返回当前配置（含真实 Key，仅供本站管理用；建议全程 HTTPS）
  return sendJSON(res, 200, { config, presets: PRESETS });
}

async function handlePostSettings(req, res, body) {
  if (!authorized(req)) return sendJSON(res, 401, { error: '访问密码不正确' });
  let input;
  try { input = JSON.parse(body || '{}'); } catch (e) { return sendJSON(res, 400, { error: '配置格式错误' }); }
  const cleaned = sanitizeConfig(input);
  try {
    const savedPath = saveConfig(cleaned);
    config = cleaned;
    console.log('配置已保存：' + savedPath);
    return sendJSON(res, 200, { ok: true, savedPath, config });
  } catch (e) {
    return sendJSON(res, 500, { error: '保存失败：' + e.message });
  }
}

// ---------- HTTP 服务器 ----------

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const pathname = url.pathname;

  if (req.method === 'GET' && (pathname === '/' || pathname === '/index.html')) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html')));
  }

  if (req.method === 'GET' && pathname === '/health') {
    return sendJSON(res, 200, { ok: true, provider: config.provider, mock: isMock(config) });
  }

  if (req.method === 'GET' && pathname === '/api/models') return handleModels(req, res);
  if (req.method === 'GET' && pathname === '/api/settings') return handleGetSettings(req, res);
  if (req.method === 'POST' && pathname === '/api/settings') {
    let body = '';
    req.on('data', c => { body += c; if (body.length > 1024 * 1024) { req.destroy(); } });
    req.on('end', () => handlePostSettings(req, res, body));
    return;
  }

  if (req.method === 'GET' && pathname === '/api/cost') {
    if (!authorized(req)) return sendJSON(res, 401, { error: '访问密码不正确' });
    const model = url.searchParams.get('model') || config.model || '';
    const n = url.searchParams.get('n') || '1';
    const resolution = normalizeResolution(url.searchParams.get('resolution') || 'auto');
    const tiers = (config.pricing && typeof config.pricing === 'object') ? config.pricing : {};
    const key = tiers[resolution] != null ? resolution : (config.resolutions && config.resolutions[0]) || '1k';
    const unit = tiers[key] != null ? Number(tiers[key]) : null;
    const count = Math.max(1, Math.min(parseInt(n, 10) || 1, 15));
    const estimated = unit === null ? null : Math.round(unit * count * 100) / 100;
    return sendJSON(res, 200, {
      model, unitCredits: unit, unitRmb: unit === null ? null : Math.round(unit * (Number(config.creditRmb) || 0.035) * 1000) / 1000,
      n: count, resolution: key, creditRmb: Number(config.creditRmb) || 0.035, estimated, priceKnown: estimated !== null
    });
  }

  if (req.method === 'POST' && pathname === '/api/upload') {
    if (!authorized(req)) return sendJSON(res, 401, { error: '访问密码不正确' });
    const chunks = [];
    let size = 0; let tooBig = false;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_UPLOAD_BYTES + 1024) { tooBig = true; sendJSON(res, 413, { error: '图片超过 10MB 上限，请压缩后再上传' }); req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => { if (!tooBig) handleUpload(req, res, Buffer.concat(chunks), url.searchParams); });
    return;
  }

  if (req.method === 'POST' && pathname === '/api/generate') {
    let body = ''; let size = 0; let tooBig = false;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > 2 * 1024 * 1024) { tooBig = true; sendJSON(res, 413, { error: '请求内容过大' }); req.destroy(); return; }
      body += chunk;
    });
    req.on('end', () => { if (!tooBig) handleGenerate(req, res, body); });
    return;
  }

  sendJSON(res, 404, { error: 'Not Found' });
});

server.listen(PORT, HOST, () => {
  console.log('AI 生图站（通用版）已启动，端口 ' + PORT + '，服务商：' + config.provider +
    (isMock(config) ? '（🧪 模拟模式）' : ''));
});
